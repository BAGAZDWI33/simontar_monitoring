<?php
    // Update the path below to your autoload.php,
    // see https://getcomposer.org/doc/01-basic-usage.md
    require_once '/path/to/vendor/autoload.php';
    use Twilio\Rest\Client;

    $sid    = "AC605cc7e794c52a7cae0ce258817e4d01";
    $token  = "[AuthToken]";
    $twilio = new Client($sid, $token);

    $message = $twilio->messages
      ->create("whatsapp:+6282324757905", // to
        array(
          "from" => "whatsapp:+14155238886",
          "contentSid" => "HX350d429d32e64a552466cafecbe95f3c",
          "contentVariables" => "{"1":"12/1","2":"3pm"}",
          "body" => "Your Message"
        )
      );

print($message->sid);