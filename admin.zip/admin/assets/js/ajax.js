// Fungsi untuk mengambil data sensor menggunakan AJAX
function fetchSensorData() {
    $.ajax({
        url: 'sensor_data.php', // Endpoint PHP untuk membaca data sensor
        method: 'GET',
        dataType: 'json',
        success: function (data) {
            if (!data.error) {
                // Update nilai sensor di halaman
                $('#ph-value').text(data.pH);
                $('#tds-value').text(data.TDS + " ppm");
                $('#temp-value').text(data.temperature + " °C");
            } else {
                console.error("Error fetching data:", data.message);
            }
        },
        error: function (err) {
            console.error("Error fetching data:", err);
        }
    });
}

// Panggil fungsi setiap 1 detik
setInterval(fetchSensorData, 1000); // Memanggil ulang fungsi setiap 1 detik
fetchSensorData(); // Panggilan pertama langsung
